DOG WALK BUDDY WEBSITE

Upload all files in this folder to a static web host such as GitHub Pages.

Features:
- Customer booking page
- Leo / Dylan / Leo + Dylan together
- 30 minutes = £5
- 45 minutes = £10
- 1 hour = £15
- Profiles
- Availability
- Ratings
- Earnings
- Local browser storage
- Mobile-friendly app-style layout
